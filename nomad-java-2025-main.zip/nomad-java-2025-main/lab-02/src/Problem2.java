public class Problem2 {
    public static void main(String[] args){
        String word1 = "I";
        String word2 = "Love";
        String word3 = "Java";

        System.out.println(word1 + ' ' + word2 + ' ' + word3);
    }
}
