public class Problem3 {
    public static void main(String[] args){
        String part1 = "Java is ";
        String part2 = "cool!";

        System.out.println(part1 + part2);
        System.out.println(part1);
        System.out.println(part2);
    }
}
